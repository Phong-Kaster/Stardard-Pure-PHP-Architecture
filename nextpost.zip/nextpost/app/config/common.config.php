<?php 
// Used for cache control
define("VERSION", "040300"); 

// Application version name
define("APP_VERSION", "4.3.0"); 

// Default timezone
date_default_timezone_set("UTC"); 

// Defaullt multibyte encoding
mb_internal_encoding("UTF-8"); 
