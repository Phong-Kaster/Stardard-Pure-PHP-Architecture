<?php 
require_once "deprecated.helper.php";

require_once "common.helper.php";
require_once "plugin.helper.php";
require_once "theme.helper.php";
